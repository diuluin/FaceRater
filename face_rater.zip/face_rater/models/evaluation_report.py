from datetime import datetime

class EvaluationReport:
    def __init__(self, user: str, score: int):
        self.user = user
        self.score = score
        self.timestamp = datetime.now().isoformat()

class UserImage:
    def __init__(self, file_path: str, user_name: str):
        self.file_path = file_path
        self.user_name = user_name

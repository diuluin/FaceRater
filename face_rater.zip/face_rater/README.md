# Face Rater

This is a simple Python project that simulates face rating from 1 to 10 using a dummy evaluator.

## How to run

```bash
python main.py
```

## How to test

```bash
python -m unittest discover tests
```

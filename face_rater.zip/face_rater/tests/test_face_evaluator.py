import unittest
from face_evaluator import DummyFaceEvaluator

class TestEvaluator(unittest.TestCase):
    def test_score_range(self):
        evaluator = DummyFaceEvaluator()
        for _ in range(10):
            score = evaluator.evaluate("dummy.jpg")
            self.assertTrue(1 <= score <= 10)

if __name__ == "__main__":
    unittest.main()
